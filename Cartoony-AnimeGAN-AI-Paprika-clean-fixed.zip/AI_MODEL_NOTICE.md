# Cartoony AI model

The project now bundles `app/src/main/assets/AnimeGANv2_Paprika.onnx` and uses ONNX Runtime on-device for neural video stylization.

The model is from the AnimeGANv2 ecosystem. Review the upstream model/repository license terms before distributing the application, especially for commercial use. The upstream AnimeGANv2 project states that commercial use requires authorization.

No cloud API key is required for the model itself.
