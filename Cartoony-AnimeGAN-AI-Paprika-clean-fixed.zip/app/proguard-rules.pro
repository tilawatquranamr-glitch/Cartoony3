
# ONNX Runtime reflection/native bindings
-keep class ai.onnxruntime.** { *; }
