package com.cartoony.app.data.converter

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import androidx.media3.common.GlTextureInfo
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlRect
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.ByteBufferGlEffect
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Real neural cartoon/anime effect using the bundled AnimeGANv2 Hayao ONNX model.
 *
 * The input frame is read back by Media3's ByteBufferGlEffect, processed by ONNX Runtime,
 * then uploaded back to the current GL output texture. This is intentionally CPU/NN based,
 * not a color/edge shader filter.
 */
@OptIn(UnstableApi::class)
class AnimeGanGlEffect(
    private val context: Context,
    private val modelAsset: String = MODEL_HAYAO
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        if (useHdr) {
            throw VideoFrameProcessingException(IllegalArgumentException("HDR input is not supported by AnimeGANv2"))
        }
        return ByteBufferGlEffect(Processor(context.applicationContext, modelAsset))
            .toGlShaderProgram(context, useHdr)
    }

    private class Processor(
        private val context: Context,
        private val modelAsset: String
    ) : ByteBufferGlEffect.Processor<Bitmap> {
        private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
            Thread(r, "Cartoony-AnimeGAN").apply { priority = Thread.NORM_PRIORITY - 1 }
        }
        private val environment = OrtEnvironment.getEnvironment()
        private val session: OrtSession
        private val inputName: String
        private val outputName: String
        private var modelWidth = 256
        private var modelHeight = 256
        private var outputTextureId = 0
        private var outputProgram: GlProgram? = null

        init {
            val modelBytes = context.assets.open(modelAsset).use { it.readBytes() }
            val modelBuffer = ByteBuffer.allocateDirect(modelBytes.size)
                .order(ByteOrder.nativeOrder())
            modelBuffer.put(modelBytes).flip()
            session = environment.createSession(modelBuffer, OrtSession.SessionOptions())
            inputName = session.inputNames.first()
            outputName = session.outputNames.first()
        }

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            val longest = maxOf(inputWidth, inputHeight)
            val scale = minOf(1f, MAX_MODEL_SIDE.toFloat() / longest.toFloat())
            modelWidth = roundTo32((inputWidth * scale).toInt())
            modelHeight = roundTo32((inputHeight * scale).toInt())
            modelWidth = modelWidth.coerceIn(256, MAX_MODEL_SIDE)
            modelHeight = modelHeight.coerceIn(256, MAX_MODEL_SIDE)
            ensureOutputProgram()
            return Size(modelWidth, modelHeight)
        }

        override fun getScaledRegion(presentationTimeUs: Long): GlRect = GlRect(modelWidth, modelHeight)

        override fun processImage(
            image: ByteBufferGlEffect.Image,
            presentationTimeUs: Long
        ): ListenableFuture<Bitmap> {
            // The Image buffer is only valid until the future completes, so copy it now.
            val inputBitmap = image.copyToBitmap()
            val future = SettableFuture.create<Bitmap>()
            executor.execute {
                try {
                    future.set(runInference(inputBitmap))
                } catch (t: Throwable) {
                    future.setException(t)
                } finally {
                    inputBitmap.recycle()
                }
            }
            return future
        }

        private fun runInference(source: Bitmap): Bitmap {
            val resized = Bitmap.createScaledBitmap(source, modelWidth, modelHeight, true)
            val pixels = IntArray(modelWidth * modelHeight)
            resized.getPixels(pixels, 0, modelWidth, 0, 0, modelWidth, modelHeight)
            if (resized !== source) resized.recycle()

            val planeSize = modelWidth * modelHeight
            val input = ByteBuffer.allocateDirect(planeSize * 3 * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
            val red = FloatArray(planeSize)
            val green = FloatArray(planeSize)
            val blue = FloatArray(planeSize)
            for (i in pixels.indices) {
                val c = pixels[i]
                red[i] = (((c ushr 16) and 0xFF) / 127.5f) - 1f
                green[i] = (((c ushr 8) and 0xFF) / 127.5f) - 1f
                blue[i] = ((c and 0xFF) / 127.5f) - 1f
            }
            input.put(red).put(green).put(blue).rewind()

            val shape = longArrayOf(1, 3, modelHeight.toLong(), modelWidth.toLong())
            val tensor = OnnxTensor.createTensor(environment, input, shape)
            try {
                synchronized(session) {
                    session.run(mapOf(inputName to tensor)).use { result ->
                        val value = result.get(outputName).orElseThrow {
                            IllegalStateException("AnimeGANv2 output not found: $outputName")
                        }
                        val outputTensor = value as OnnxTensor
                        val output = outputTensor.floatBuffer
                            ?: throw IllegalStateException("AnimeGANv2 returned a non-float output")
                        output.rewind()
                        return tensorToBitmap(output, modelWidth, modelHeight)
                    }
                }
            } finally {
                tensor.close()
            }
        }

        private fun tensorToBitmap(output: FloatBuffer, width: Int, height: Int): Bitmap {
            val plane = width * height
            val pixels = IntArray(plane)
            for (i in 0 until plane) {
                val r = (((output.get(i) + 1f) * 127.5f).coerceIn(0f, 255f)).toInt()
                val g = (((output.get(plane + i) + 1f) * 127.5f).coerceIn(0f, 255f)).toInt()
                val b = (((output.get(2 * plane + i) + 1f) * 127.5f).coerceIn(0f, 255f)).toInt()
                pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
        }

        override fun finishProcessingAndBlend(
            outputFrame: GlTextureInfo,
            presentationTimeUs: Long,
            result: Bitmap
        ) {
            try {
                ensureOutputProgram()
                if (outputTextureId == 0) {
                    outputTextureId = GlUtil.generateTexture()
                }
                GlUtil.setTexture(outputTextureId, result)
                GlUtil.focusFramebufferUsingCurrentContext(
                    outputFrame.fboId,
                    outputFrame.width,
                    outputFrame.height
                )
                val program = outputProgram ?: return
                program.use()
                program.setSamplerTexIdUniform("uTexSampler", outputTextureId, 0)
                program.bindAttributesAndUniforms()
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GlUtil.checkGlError()
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e, presentationTimeUs)
            } finally {
                result.recycle()
            }
        }

        private fun ensureOutputProgram() {
            if (outputProgram != null) return
            try {
                val program = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
                program.setBufferAttribute(
                    "aFramePosition",
                    GlUtil.getNormalizedCoordinateBounds(),
                    GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
                )
                // Flip Y because Bitmap uses top-left origin while GL textures use bottom-left.
                program.setBufferAttribute(
                    "aTexCoords",
                    floatArrayOf(
                        0f, 1f, 0f, 1f,
                        1f, 1f, 0f, 1f,
                        0f, 0f, 0f, 1f,
                        1f, 0f, 0f, 1f
                    ),
                    GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
                )
                program.setFloatsUniform("uTransformationMatrix", GlUtil.create4x4IdentityMatrix())
                outputProgram = program
            } catch (e: GlUtil.GlException) {
                throw IllegalStateException("Failed to initialize AI output renderer", e)
            }
        }

        override fun release() {
            executor.shutdownNow()
            try {
                outputProgram?.delete()
                outputProgram = null
                if (outputTextureId != 0) {
                    GlUtil.deleteTexture(outputTextureId)
                    outputTextureId = 0
                }
            } catch (_: Exception) {
            }
            session.close()
        }

        private fun resolveModelAsset(requested: String): String {
            return try {
                context.assets.open(requested).use { }
                requested
            } catch (_: Exception) {
                MODEL_PAPRIKA
            }
        }

        private companion object {
            const val MAX_MODEL_SIDE = 768
            const val VERTEX_SHADER = """
attribute vec4 aFramePosition;
attribute vec4 aTexCoords;
uniform mat4 uTransformationMatrix;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = uTransformationMatrix * aFramePosition;
  vTexSamplingCoord = aTexCoords.xy;
}
"""
            const val FRAGMENT_SHADER = """
precision mediump float;
uniform sampler2D uTexSampler;
varying vec2 vTexSamplingCoord;
void main() {
  gl_FragColor = texture2D(uTexSampler, vTexSamplingCoord);
}
"""

            fun roundTo32(value: Int): Int = ((value + 31) / 32) * 32
        }
    }

    companion object {
        const val MODEL_HAYAO = "AnimeGANv2_Hayao.onnx"
        const val MODEL_SHINKAI = "AnimeGANv2_Shinkai.onnx"
        const val MODEL_PAPRIKA = "AnimeGANv2_Paprika.onnx"
    }
}
