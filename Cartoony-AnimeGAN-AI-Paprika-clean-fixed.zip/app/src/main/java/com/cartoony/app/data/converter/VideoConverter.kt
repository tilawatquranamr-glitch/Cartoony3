package com.cartoony.app.data.converter

import android.net.Uri
import com.cartoony.app.model.CartoonStyle
import com.cartoony.app.model.VoiceStyle

/**
 * Contract for video stylization. Implementations must either return a real,
 * playable file or fail with a [VideoConversionException]; they must never
 * silently return a copy of the input.
 */
interface VideoConverter {

    suspend fun convert(
        inputUri: Uri,
        style: CartoonStyle,
        voice: VoiceStyle,
        onProgress: (progress: Float, stageDescription: String) -> Unit
    ): Result<Uri>

    /** Cancels any running conversion. */
    fun cancel()
}

/** Conversion failure carrying a ready-to-display Arabic message. */
class VideoConversionException(
    val errorCode: String,
    val localizedMessageAr: String,
    val canRetry: Boolean = true,
    cause: Throwable? = null
) : Exception(localizedMessageAr, cause)
