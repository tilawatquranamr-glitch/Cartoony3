package com.cartoony.app.data.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Handles exporting and saving converted cartoon videos to Android MediaStore in Movies/Cartoony.
 */
class MediaStoreVideoSaver(private val context: Context) {

    /**
     * Saves the converted video file to the system gallery under Movies/Cartoony.
     *
     * @param sourceUri Uri of the processed video
     * @param originalName Name of the original video (e.g. "holiday.mp4")
     * @param styleName Identifier of the chosen style (e.g. "anime")
     * @return Result containing the saved MediaStore content Uri
     */
    suspend fun saveToGallery(
        sourceUri: Uri,
        originalName: String,
        styleName: String
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val baseName = originalName.substringBeforeLast(".")
            val finalFileName = "${baseName}_${styleName}.mp4"

            val contentValues = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, finalFileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/Cartoony")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }

            val destinationUri = context.contentResolver.insert(collection, contentValues)
                ?: return@withContext Result.failure(Exception("Failed to create MediaStore entry"))

            val sourceStream: InputStream? = if (sourceUri.scheme == "file") {
                FileInputStream(File(sourceUri.path ?: ""))
            } else {
                context.contentResolver.openInputStream(sourceUri)
            }

            val outputStream: OutputStream? = context.contentResolver.openOutputStream(destinationUri)

            if (sourceStream == null || outputStream == null) {
                return@withContext Result.failure(Exception("Cannot open streams for video copy"))
            }

            sourceStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }

            // Release pending flag on Android 10+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                context.contentResolver.update(destinationUri, contentValues, null, null)
            }

            Result.success(destinationUri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
