package com.cartoony.app.model

import android.net.Uri
import java.util.Locale

/**
 * Data class encapsulating picked video information including duration, resolution, and file size.
 */
data class VideoMetadata(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int = 0,
    val height: Int = 0
) {
    /**
     * Formats duration in mm:ss format.
     */
    val formattedDuration: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        }

    /**
     * Formats file size in readable MB/KB string.
     */
    val formattedSize: String
        get() {
            return when {
                sizeBytes >= 1024 * 1024 -> {
                    val mb = sizeBytes.toDouble() / (1024 * 1024)
                    String.format(Locale.getDefault(), "%.1f MB", mb)
                }
                sizeBytes >= 1024 -> {
                    val kb = sizeBytes.toDouble() / 1024
                    String.format(Locale.getDefault(), "%.1f KB", kb)
                }
                else -> "$sizeBytes B"
            }
        }
}
