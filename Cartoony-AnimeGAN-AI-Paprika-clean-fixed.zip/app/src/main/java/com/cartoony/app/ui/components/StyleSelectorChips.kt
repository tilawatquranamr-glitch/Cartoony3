package com.cartoony.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cartoony.app.R
import com.cartoony.app.model.CartoonStyle
import com.cartoony.app.ui.theme.CartoonyOrange
import com.cartoony.app.ui.theme.CartoonyPurple

/**
 * Horizontally scrollable style chips (Anime, Cartoon, Comic, Stop Motion, Sketch),
 * each equipped with a vibrant visual thumbnail and active highlight.
 */
@Composable
fun StyleSelectorChips(
    selectedStyle: CartoonStyle,
    onStyleSelected: (CartoonStyle) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = stringResource(R.string.select_style),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CartoonStyle.entries.forEach { style ->
                val isSelected = style == selectedStyle
                val borderColor by animateColorAsState(
                    targetValue = if (isSelected) CartoonyPurple else Color.Transparent,
                    label = "border"
                )

                StyleChipItem(
                    style = style,
                    isSelected = isSelected,
                    borderColor = borderColor,
                    onClick = { onStyleSelected(style) }
                )
            }
        }
    }
}

@Composable
private fun StyleChipItem(
    style: CartoonStyle,
    isSelected: Boolean,
    borderColor: Color,
    onClick: () -> Unit
) {
    val chipBackground = if (isSelected) {
        MaterialTheme.colorScheme.surface
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    }

    Row(
        modifier = Modifier
            .height(52.dp)
            .shadow(
                elevation = if (isSelected) 4.dp else 1.dp,
                shape = RoundedCornerShape(20.dp),
                spotColor = CartoonyPurple.copy(alpha = 0.3f)
            )
            .clip(RoundedCornerShape(20.dp))
            .background(chipBackground)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) CartoonyPurple else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail Avatar representing the art style with distinct palette
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(getStyleBrush(style)),
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(Color.Black.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else {
                Text(
                    text = style.arTitle.take(1),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.padding(end = 8.dp)) {
            Text(
                text = stringResource(style.titleResId),
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 14.sp,
                color = if (isSelected) CartoonyPurple else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = style.enTitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun getStyleBrush(style: CartoonStyle): Brush {
    return when (style) {
        CartoonStyle.ANIME -> Brush.linearGradient(listOf(Color(0xFF8E24AA), Color(0xFFE91E63), Color(0xFFFF80AB)))
        CartoonStyle.ANIME_SHINKAI -> Brush.linearGradient(listOf(Color(0xFF1565C0), Color(0xFF42A5F5), Color(0xFF90CAF9)))
        CartoonStyle.ANIME_PAPRIKA -> Brush.linearGradient(listOf(Color(0xFFFF6F00), Color(0xFFFFCA28), Color(0xFFFF8A65)))
        CartoonStyle.CARTOON_2D -> Brush.linearGradient(listOf(Color(0xFFFF9100), Color(0xFFFFD600)))
        CartoonStyle.COMIC -> Brush.linearGradient(listOf(Color(0xFFD50000), Color(0xFF2979FF)))
        CartoonStyle.STOP_MOTION -> Brush.linearGradient(listOf(Color(0xFF795548), Color(0xFFFFAB91)))
        CartoonStyle.SKETCH -> Brush.linearGradient(listOf(Color(0xFF37474F), Color(0xFF90A4AE)))
    }
}
