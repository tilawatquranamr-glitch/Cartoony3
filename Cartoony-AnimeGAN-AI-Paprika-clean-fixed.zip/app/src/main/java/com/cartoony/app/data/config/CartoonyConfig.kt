package com.cartoony.app.data.config

/**
 * Central configuration for the on-device conversion engine.
 */
object CartoonyConfig {

    // Longest video accepted (on-device processing is free but slow for very long clips)
    const val MAX_ALLOWED_VIDEO_DURATION_MS = 10 * 60_000L // 10 minutes

    // Output is downscaled to this height when the input is taller (speed and file size)
    const val MAX_OUTPUT_HEIGHT = 720
}
